<footer class="footer text-right">
    2021 © GLOBAL PHARMA.
</footer>
