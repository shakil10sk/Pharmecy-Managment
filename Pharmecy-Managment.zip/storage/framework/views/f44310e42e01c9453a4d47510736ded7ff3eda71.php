

<?php $__env->startSection('title'); ?>
GLOBAL PHARMA
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-section'); ?>
<h1>View Medicine</h1><br>

<div class="table-responsive">
    <table class="table table-striped">
        <tr>
            <td class="">SI</td>
            <td>Medicne Name</td>
            <td>Generic Name</td>
            <td>Category</td>
            <td>Manufacturer</td>
            <td>Shelf</td>
            <td>Quentity</td>
            <td>Strength</td>
            <td>Selling Price</td>
            <td>Manufacturer price</td>
            <td>Product Code</td>
            <td>Buying Date</td>
            <td>Manufecture Date</td>
            <td>Expire Date</td>
            <td>Images</td>

            <td>Action</td>
        </tr>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
           <td><?php echo e(++$key); ?></td>
           <td><?php echo e($value->medicine_name); ?></td>
           <td><?php echo e($value->genric_name); ?></td>
           <td><?php echo e($value->category); ?></td>
           <td><?php echo e($value->manufecture); ?></td>
           <td><?php echo e($value->self_number); ?></td>
           <td><?php echo e($value->qty); ?></td>
           <td><?php echo e($value->strength); ?></td>
           <td><?php echo e($value->sell_price); ?></td>
           <td><?php echo e($value->manufecture_price); ?></td>
           <td><?php echo e($value->Product_code); ?></td>
           <td><?php echo e($value->buy_date); ?></td>
           <td><?php echo e($value->manufecturer_date); ?></td>
           <td><?php echo e($value->expire_date); ?></td>
           <td><img src="<?php echo e(asset('images/'.$value->Images)); ?>" alt="" width="50" height="50"></td>
           <td>
               <a href="<?php echo e(asset('/medicine/post/edit/'. $value->id )); ?>">Edit</a> |
               

                <a href="<?php echo e(asset('/medicine/post/delete/'. $value->id )); ?>">Delete</a> |
            <br>
            <a href="<?php echo e(asset('/medicine/show/'. $value->id )); ?>">Show</a> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </table>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/medicine/view_medicine.blade.php ENDPATH**/ ?>