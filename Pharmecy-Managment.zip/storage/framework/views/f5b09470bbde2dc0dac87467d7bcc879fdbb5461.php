

<?php $__env->startSection('title'); ?>
GLOBAL PHARMA
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-section'); ?>
<!-- Page-Title -->
<div class="row">
    <div class="col-sm-12">
        <h4 class="pull-left page-title">Manufacturer Table</h4>
        <ol class="breadcrumb pull-right">
            <li><a href="#">GLOBAL Pharma</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Manufacturer Table</li>
        </ol>
    </div>
</div>


<div class="panel">

    <div class="panel-body">
        <!-- <div class="row">
            <div class="col-sm-6">
                <div class="m-b-30">
                    <button id="addToTable" onclick="window.location.href='/employee/add'"
                        class="btn btn-primary waves-effect text-light waves-light">Add
                        <i class="fa fa-plus"></i></button>
                </div>
            </div>
        </div> -->
        <?php echo $__env->make('message.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="datatable-Manufecturer">
                <thead>
                    <tr>
                        <th>S.I</th>
                        <th>Manufacturer</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $manufacturer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="gradeX">
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($value->manufecture); ?></td>
                           
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
       <div class="col-md-12 text-right">
        
       </div>
    </div>
    <!-- end: page -->

</div> <!-- end Panel -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/manufecturer/view.blade.php ENDPATH**/ ?>