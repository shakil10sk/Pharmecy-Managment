<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
    <meta name="author" content="Coderthemes">
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon_1.ico')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> </title>
    <?php echo $__env->make('frontend.dashboard.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</head>

<body class="fixed-left">
    <!-- Begin page -->
    <div id="wrapper">
        <!-- Top Bar Start -->
        <?php echo $__env->make('frontend.dashboard.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <h4 class="pull-left page-title">Invoice</h4>
                            <ol class="breadcrumb pull-right">
                                <li><a href="/">GLOBAL PHARMA</a></li>
                                <li><a href="/POS">POS</a></li>
                                <li class="active">Invoice</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <!-- <div class="panel-heading">
                                            <h4>Invoice</h4>
                                        </div> -->
                                <div class="panel-body">
                                    <div class="clearfix">
                                        <div class="pull-left">
                                            <h4 class="text-right">GLOBAL PHARMA</h4>
                                        </div>
                                        <div class="pull-right">
                                            <h4>Invoice # <br>
                                                <strong><?php echo e(date('d/m/y')); ?></strong>
                                            </h4>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">

                                            <div class="pull-left m-t-5">

                                                <address>
                                                    <strong>Name : <?php echo e($customar->customar_name); ?></strong><br>
                                                    Address : <?php echo e($customar->address); ?><br>
                                                    City : <?php echo e($customar->custoamr_city); ?><br>
                                                    Phone : <?php echo e($customar->phone); ?>

                                                </address>

                                            </div>
                                            <div class="pull-right m-t-5">
                                                <p><strong>Order Date : </strong>
                                                    <?php echo e(date("l jS \of F Y")); ?></p>
                                                <p class="m-t-5"><strong>Order Status : </strong> <span
                                                        class="label label-pink">Active</span></p>
                                                <?php
                                                    // $order=DB::table('orders')->select('id')->first();
                                                    $i=1;
                                                ?>

                                                <p class="m-t-5"><strong>Order ID : </strong> #202100<?php echo e(++$i); ?>

                                                    

                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m-h-5"></div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table m-t-5">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Item</th>
                                                            <th>Quantity</th>
                                                            <th>Unit Cost</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $sl=0;
                                                        ?>
                                                        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e(++$sl); ?></td>
                                                                <td><?php echo e($row->name); ?></td>
                                                                <td><?php echo e($row->qty); ?> pcs</td>
                                                                <td>৳ <?php echo e($row->price); ?></td>
                                                                <td>৳ <?php echo e($row->price*$row->qty); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" style="border-radius: 0px;">
                                        <div class="col-md-3 col-md-offset-9">
                                            <h4 class="text-right"><b>Sub-total :</b> ৳<?php echo e(Cart::subtotal()); ?></h4>
                                            
                                            
                                            <hr>
                                            <h3 class="text-right">Total : ৳<?php echo e(Cart::total(2)); ?></h3>
                                        </div>
                                    </div>

                                    <div class="hidden-print">
                                        <div class="pull-right">
                                            <a href="#" onclick="window.print()"
                                                class="btn btn-inverse waves-effect waves-light"><i
                                                    class="fa fa-print"></i></a>
                                            <a href="#" class="btn btn-primary waves-effect waves-light"
                                                data-toggle="modal" data-target="#con-close-modal">Submit</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    


                    <form class="container" action="<?php echo e(url('/final-invoice')); ?>" method="post">
                        <?php echo $__env->make('message.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo csrf_field(); ?>
                        <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog"
                            aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"
                                            aria-hidden="true">×</button>
                                        <h4 class="modal-title text-info">Invoice Of <?php echo e($customar->customar_name); ?>

                                            <span class="pull-right">Total: <?php echo e(Cart::total()); ?></span></h4>
                                    </div>
                                    <?php if(session()->has('success')): ?>
                                        <div class="alert alert-success" style="color: green;font-weight: bold;">
                                            <?php echo e(session()->get('success')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="field-1" class="control-label">Payment<span
                                                            class="text-danger">
                                                            *</span></label>
                                                    <select name="payment_status" id="" class="form-control">
                                                        <option value="handcash"> Hand Cash </option>
                                                        <option value="cheack"> Cheack </option>                                                        
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="field-2" class="control-label">Pay<span
                                                            class="text-danger">
                                                            *</span></label>
                                                    <input type="text" class="form-control" required id="field-2" name="pay"
                                                        placeholder="payment amount">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="hidden" class="form-control" required id="field-3" name="due"
                                                        value="0">
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="customar_id" value="<?php echo e($customar->id); ?>">
                                        <input type="hidden" name="order_date"
                                            value="<?php echo e(date('d/m/y')); ?>">
                                        <input type="hidden" name="order_status" value="Active">
                                        <input type="hidden" name="total_products" value="<?php echo e(Cart::count()); ?>">
                                        <input type="hidden" name="sub_total" value="<?php echo e(Cart::subtotal()); ?>">
                                        <input type="hidden" name="vat" value="<?php echo e(Cart::tax()); ?>">
                                        <input type="hidden" name="total" value="<?php echo e(Cart::total()); ?>">
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default waves-effect"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-info waves-effect waves-light">Save
                                                changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.modal -->
                    </form>
                </div> <!-- container -->
            </div> <!-- content -->
            
            <?php echo $__env->make('frontend.dashboard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->

        <!-- Right Sidebar chat -->
        
        <!-- /Right-bar -->

    </div>
    <!-- END wrapper -->


    <?php echo $__env->make('frontend.dashboard.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/user/invoice/view.blade.php ENDPATH**/ ?>