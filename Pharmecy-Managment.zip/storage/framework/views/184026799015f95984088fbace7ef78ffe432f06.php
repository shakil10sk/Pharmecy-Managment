 <?php $__env->startSection('title'); ?> GLOBAL PHARMA
<?php $__env->stopSection(); ?> <?php $__env->startSection('content-section'); ?>
<!-- Page-Title -->
<div class="row">
    <div class="col-sm-12">
        <h4 class="pull-left page-title">Customar View</h4>
        <ol class="breadcrumb pull-right">
            <li>
                <a href="#">GLOBAL</a>
            </li>
            <li>
                <a href="#">Customar</a>
            </li>
            <li class="active">Customar Table</li>
        </ol>
    </div>
</div>

<div class="panel">

    <div class="panel-body">
        <div class="row">
            <div class="col-sm-6">
                <div class="m-b-30">
                    <button
                        id="addToTable"
                        onclick="window.location.href='/customar/add'"
                        class="btn btn-primary waves-effect text-light waves-light">Add
                        <i class="fa fa-plus"></i>
                    </button>
                </div>
            </div>
        </div>
        <?php echo $__env->make('message.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="datatable-editable">
                <thead>
                    <tr>
                        <th>S.I</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Photo</th>
                        <th>Address</th>
                        <th>Account Number</th>
                        <th>Bank Name</th>
                        <th>Bank Branch Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeX">
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($value->customar_name); ?></td>
                        <td><?php echo e($value->email); ?></td>
                        <td><?php echo e($value->phone); ?></td>
                        <td><?php echo e($value->custoamr_city); ?></td>
                        <td><img src="<?php echo e(asset('images/customar/'.$value->photo)); ?>" alt="" width="50" height="50"></td>
                        <td><?php echo e($value->address); ?></td>
                        <td><?php echo e($value->ac_num); ?></td>
                        <td><?php echo e($value->bank_name); ?></td>
                        <td><?php echo e($value->bank_branch); ?></td>
                        <td class="actions">
                            
                            
                            <a href="<?php echo e(asset('/customar/edit/ '.$value->id)); ?>" class="on-default edit-row">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <a href="<?php echo e(asset('/customar/delete/ '.$value->id)); ?>" class="on-default remove-row">
                                <i class="fa fa-trash-o"></i>
                            </a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        <div class="col-md-12 text-right">
            <?php echo e($customar->links()); ?>

        </div>
    </div>
    <!-- end: page -->

</div>
<!-- end Panel -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/customar/view_customar.blade.php ENDPATH**/ ?>