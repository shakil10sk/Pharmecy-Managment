<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">
        <link rel="shortcut icon" href="<?php echo e(asset('favicon.jpg')); ?>" type="image/x-icon">
        <link rel="icon" href="<?php echo e(asset('favicon.jpg')); ?>" type="image/x-icon">
        <title><?php echo $__env->yieldContent('title'); ?> </title>


        <?php echo $__env->make('frontend.dashboard.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;




    </head>



    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
           <?php echo $__env->make('frontend.dashboard.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->
           <?php echo $__env->make('frontend.dashboard.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Left Sidebar End -->



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">


                        <!-- Page-Title -->
                        <?php echo $__env->yieldContent('title-section'); ?>


                        <?php echo $__env->yieldContent('content-section'); ?>


                        
                        

                    </div> <!-- container -->

                </div> <!-- content -->

                
                <?php echo $__env->make('frontend.dashboard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>
            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


            <!-- Right Sidebar chat -->
            
            <!-- /Right-bar -->

        </div>
        <!-- END wrapper -->


        <?php echo $__env->make('frontend.dashboard.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/master.blade.php ENDPATH**/ ?>