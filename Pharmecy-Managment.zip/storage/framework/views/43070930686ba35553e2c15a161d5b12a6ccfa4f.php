

<?php $__env->startSection('title'); ?>
GLOBAL PHARMA
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title-section'); ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="pull-left page-title">Welcome <?php echo e(Auth::user()->name); ?>!</h4>
            <ol class="breadcrumb pull-right">
                <li><a href="#">GLOBAL PHRMA</a></li>
                <li class="active"><?php echo e(Auth::user()->name); ?> Dashboard</li>
            </ol>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-section'); ?>

    <!-- Start Widget -->
    <?php echo $__env->make('frontend.dashboard.partials.widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End row-->

    
     <?php echo $__env->make('frontend.dashboard.partials.webstatus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/index.blade.php ENDPATH**/ ?>