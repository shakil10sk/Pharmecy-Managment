<footer class="footer text-right">
    2021 © GLOBAL PHARMA.
</footer>
<?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/partials/footer.blade.php ENDPATH**/ ?>