

<?php $__env->startSection('title'); ?>
GLOBAL PHARMA
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-section'); ?>
<!-- Page-Title -->
<div class="row">
    <div class="col-sm-12">
        <h4 class="pull-left page-title">View Emplyoee</h4>
        <ol class="breadcrumb pull-right">
            <li><a href="/">GLOBAL PHARMA</a></li>
            <li><a href="/employee/add">emplyoee</a></li>
            <li class="active">Emplyoee Table</li>
        </ol>
    </div>
</div>


<div class="panel">

    <div class="panel-body">
        <div class="row">
            <div class="col-sm-6">
                <div class="m-b-30">
                    <button id="addToTable" onclick="window.location.href='/employee/add'"
                        class="btn btn-primary waves-effect text-light waves-light">Add
                        <i class="fa fa-plus"></i></button>
                </div>
            </div>
        </div>
        <?php echo $__env->make('message.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="datatable-editable">
                <thead>
                    <tr>
                        <th>S.I</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Nid Number</th>
                        <th>City</th>
                        <th>Position</th>
                        <th>Photo</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $view_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="gradeX">
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->phone); ?></td>
                            <td><?php echo e($value->address); ?></td>
                            <td><?php echo e($value->nid_number); ?></td>
                            <td><?php echo e($value->city); ?></td>
                            <td><?php echo e($value->position); ?></td>
                            <td><img src="<?php echo e(asset('images/users/'.$value->photo)); ?>" alt="" width="50" height="50"></td>
                            <td class="actions">
                                
                                
                                <a href="<?php echo e(asset('/employee/edit/'. $value->id )); ?>" class="on-default edit-row"><i class="fa fa-pencil"></i></a>
                                <a href="<?php echo e(asset('/employee/delete/'. $value->id )); ?>" class="on-default remove-row"><i class="fa fa-trash-o"></i></a>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
       
    </div>
    <!-- end: page -->

</div> <!-- end Panel -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/employee/view.blade.php ENDPATH**/ ?>