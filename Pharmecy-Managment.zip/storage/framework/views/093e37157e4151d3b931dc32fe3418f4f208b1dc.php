


<?php $__env->startSection('content-section'); ?>

<h3>Add Customar</h3>
<form class="container" action="<?php echo e(asset('/customar')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('message.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="modal-body">
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="field-1" class="control-label">Name<span class="text-danger"> *</span></label>
                <input type="text" class="form-control " name="customar_name" id="field-1" placeholder="John" required>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="field-2" class="control-label">Email<span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="field-2" name="email" placeholder="john@gmail.com" required>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="field-3" class="control-label">Phone<span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="field-3" name="phone" required placeholder="+8801700-000000">
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-md-6">
            <div class="form-group">
                <label for="field-5" class="control-label">City</label>
                <input type="text" class="form-control" id="field-5" name="custoamr_city" placeholder="Dhaka">

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="field-10" class="control-label">Photo</label>
                <input type="file" class="form-control" name="photo" id="field-10">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="field-4" class="control-label">Address<span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="field-4"required  name="address" placeholder="Dhaka">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="field-6" class="control-label">Account Number<span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="field-6"required  name="ac_num" placeholder="73461254896325">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="field-8" class="control-label">Bank Name<span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="field-8" required  name="bank_name" placeholder="IBBL">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="field-9" class="control-label">Bank Branch<span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="field-9" required name="bank_branch" placeholder="Dhaka">
            </div>
        </div>

    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/customar/add.blade.php ENDPATH**/ ?>