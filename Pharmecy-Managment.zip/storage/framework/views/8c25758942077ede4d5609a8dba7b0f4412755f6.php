

<?php $__env->startSection('title'); ?>
ADD Medicine
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-section'); ?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <div class="panel panel-info">
            <div class="panel-heading"><h3 class="panel-titile text-white">Products Import <a href="/export" class="pull-right btn btn-danger btn-sm">Dowenload Xlsx</a></h3></div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="panel-body">
                <form action="<?php echo e(route('import')); ?>" role="form" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="files">Xlsx File Import</label>
                            <input type="file" name="import_file" required>
                        </div>
                        <button type="submit" class="btn btn-success waves-effect eaves-light">Uploads</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/medicine/importMedicine.blade.php ENDPATH**/ ?>