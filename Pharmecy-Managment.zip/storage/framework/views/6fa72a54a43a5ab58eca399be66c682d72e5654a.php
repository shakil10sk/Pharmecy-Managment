<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div><?php echo e($error); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success" style="color: green;font-weight: bold;">
   <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/message/alert.blade.php ENDPATH**/ ?>