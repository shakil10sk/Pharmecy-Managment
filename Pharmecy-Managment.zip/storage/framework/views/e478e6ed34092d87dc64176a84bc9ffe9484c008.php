

<?php $__env->startSection('title'); ?>
GLOBAL PHARMA
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-section'); ?>
<div class="row">
    <div class="col-sm-12 bg-info">
        <h4 class="pull-left page-title">POS(Point Of Sale)</h4>
        <ol class="breadcrumb pull-right">
            <li>
                <a href="/">GLOBAL PHRMA</a>
            </li>
            <li class="text-white"><?php echo e(date('d/m/y')); ?></li>
        </ol>
    </div>
</div>
<br>

<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-section'); ?>


<div class="row">

    <div class="col-md-5">
        
    <div class="price_card text-center">
        <ul class="price-features" style="border:1px solid gray">
            <table class="table table-responsive">
                <thead class="bg-info">
                    <tr>
                        <th class="text-center text-white">Name</th>
                        <th class="text-center text-white">QTY</th>
                        <th class="text-center text-white">Price</th>
                        <th class="text-center text-white">Sub Total</th>
                        <th class="text-center text-white">Action</th>
                    </tr>
                </thead>
                <?php
                    $cart=Cart::content()
                ?>
                <tbody>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($shop->name); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(url('/cart-update/'.$shop->rowId )); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" name="qty" value="<?php echo e($shop->qty); ?>" style="width: 50px">
                                    <button type="submit" class="btn btn-sm btn-success" style="margin-top:-2px;">
                                        <i class="fa fa-check "></i></button>
                                </form>
                            </td>
                            <td class="text-center"><?php echo e($shop->price); ?></td>
                            <td class="text-center"><?php echo e($shop->price*$shop->qty); ?></td>
                            <td class="text-center"><a
                                    href="<?php echo e(url('/cart-remove/'.$shop->rowId)); ?>"><i
                                        class="fa fa-trash fa-2x text-danger"></a></i>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </ul>
        <div class="pricing-footer  bg-info">
            <div class=" bg-primary">
                <p style="font-size:19px;"> Quantity: <?php echo e(Cart::count()); ?></p>
                <p style="font-size:19px;"> SubTotal: <?php echo e(Cart::subtotal()); ?></p>
                <p style="font-size:19px;"> Discount: <?php echo e(Cart::tax(0)); ?></p>
                <hr>
            </div>
            <h2 class="text-white text-center m-0">Total:- <?php echo e(Cart::total()); ?> </h2>

            
            <form action="<?php echo e(url('/create-invoice')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="panel"><br><br>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <h4 class="text-info"> Select Customar
                        <a href="#" class="btn btn-sm btn-primary waves-effect waves-light pull-right"
                            data-toggle="modal" data-target="#con-close-modal">Add New</a>
                    </h4>
                    <?php
                        $customar=DB::table('customars')->get();
                    ?>
                    <select name="cus_id" id="" class="form-control">
                        <option value="" disabled="" selected="">Select Customar</option>
                        <?php $__currentLoopData = $customar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cus->id); ?>"><?php echo e($cus->customar_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
        </div>
        <button type="submit" class="btn btn-success">Create Invoice</button>
    </div>
</div>

</form>



<div class="col-md-7">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 ">
            <div class="portfolioFilter">
                <?php $__currentLoopData = $medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <a href="#" data-filter=".webdesign"><span
                            class="h5 text-uppercase"><?php echo e($value->category); ?></span></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Datatable</h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <table id="datatable" class="table table-striped table-bordered">
                        <thead>
                            <tr class="text-center">
                                <th>Image</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>ADD</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <form action="/add-cart" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($value->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($value->medicine_name); ?>">
                                        <input type="hidden" name="qty" value="1">
                                        <input type="hidden" name="price" value="<?php echo e($value->sell_price); ?>">
                                        <td>
                                            
                                            <img src="<?php echo e(asset('images/'.$value->Images)); ?>"
                                                alt="" width="50" height="50"><br><?php echo e(++$key); ?>

                                        </td>
                                        <td><?php echo e($value->medicine_name); ?></td>
                                        <td><?php echo e($value->category); ?></td>
                                        <td><?php echo e($value->sell_price); ?></td>
                                        <td> <button type="submit" class="btn btn-sm"><i
                                                    class="fa fa-plus-square fa-2x text-info"></i></button> </td>
                                    </form>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
</div> <!-- End Row -->
<!-- End Medicine view Section-->



<form class="container" action="<?php echo e(asset('/customar')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Add Customar</h4>
                </div>
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success" style="color: green;font-weight: bold;">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-1" class="control-label">Name<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control " name="customar_name" id="field-1"
                                    placeholder="John" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-2" class="control-label">Email<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control" id="field-2" name="email"
                                    placeholder="john@gmail.com" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-3" class="control-label">Phone<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control" id="field-3" name="phone" required
                                    placeholder="+8801700-000000">
                            </div>
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-5" class="control-label">City</label>
                                <input type="text" class="form-control" id="field-5" name="custoamr_city"
                                    placeholder="Dhaka">

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <img src="#" id="image" alt="">
                                <label for="field-10" class="control-label">Photo</label>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-10" class="control-label">Photo</label>
                                <input type="file" class="form-control" name="photo" accept="image/*"
                                    onchange="readURL(this);" id="field-10">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="field-4" class="control-label">Address<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control" id="field-4" required name="address"
                                    placeholder="Dhaka">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-6" class="control-label">Account Number<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control" id="field-6" required name="ac_num"
                                    placeholder="73461254896325">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-8" class="control-label">Bank Name<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control" id="field-8" required name="bank_name"
                                    placeholder="IBBL">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="field-9" class="control-label">Bank Branch<span class="text-danger">
                                        *</span></label>
                                <input type="text" class="form-control" id="field-9" required name="bank_branch"
                                    placeholder="Dhaka">
                            </div>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" value=" Save Changes" class="btn btn-info waves-effect waves-light">Save changes</button>
                    </div>
                </div>

            </div>
        </div>
    </div><!-- /.modal -->
</form>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#image').attr('src', e.target.result).width(80).height(80);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/user/pos/pos.blade.php ENDPATH**/ ?>