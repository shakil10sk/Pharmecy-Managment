

<?php $__env->startSection('title'); ?>
ADD Category
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-section'); ?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading"><h3 class="panel-title text-white">Add Category <a href="/category/" class="pull-right btn btn-danger btn-sm">View Category</a></h3></div>

            
            <div class="panel-body">
                <form action="<?php echo e(route('store.category')); ?>" role="form" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('error')); ?>

                    </div>
                    <?php endif; ?>

                

                    <div class="form-group">
                        <div class="form-group">
                            <label for="cat">Add Category :</label>
                            <input type="text" name="category" id="cat" placeholder="Add Category" required>
                        </div>
                        <button type="submit" class="btn btn-success waves-effect eaves-light">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/pages/category/addCategory.blade.php ENDPATH**/ ?>