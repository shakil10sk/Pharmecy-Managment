<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <div class="user-details">
            <div class="pull-left">
                <img src="<?php echo e(asset('/images/users/'.Auth::User()->photo)); ?>" alt=""
                    class="thumb-md img-circle"></div>
            <div class="user-info">
                <div class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo e(Auth::user()->name); ?>

                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="javascript:void(0)">
                                <i class="md md-face-unlock"></i>
                                Profile<div class="ripple-wrapper"></div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <i class="md md-settings"></i>
                                Settings</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <i class="md md-lock"></i>
                                Lock screen</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                <i class="md md-settings-power"></i>
                                Logout</a>

                                

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                
                        </li>
                    </ul>
                </div>
                <p class="text-muted m-0">
                    <?php if(Auth::user()->role==1): ?>
                    Administrator
                    <?php elseif(Auth::user()->role==2): ?>
                    Salesman(User)
                    <?php endif; ?></p>
            </div>
        </div>
        <!--- Divider -->
        <div id="sidebar-menu">
            <ul>
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect ">
                        <i class="md md-home"></i>
                        <span>
                            Dashboard
                        </span>
                    </a>
                </li>

                <?php if(Auth::user()->role==2): ?>
                <li>
                    <a href="<?php echo e(asset('/pos')); ?>" class="waves-effect ">
                        <i class="md md-palette"></i>
                        <span>
                        Point Of Sale (POS)
                        </span>
                    </a>
                </li>
                <?php endif; ?>


            <?php if(Auth()->user()->role==1): ?>
                <li class="has_sub">
                    <a href="#" class="waves-effect">
                        <i class="md md-invert-colors-on"></i>
                        <span>
                            Medicine
                        </span>
                        <span class="pull-right">
                            <i class="md md-add"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled">
                        <li>
                            <a href="<?php echo e(asset('/medicine/add')); ?>">Add Medicine</a>
                        </li>
                        <li>
                            <a href="<?php echo e(asset('/import-medicine')); ?>">Import Medicine</a>
                        </li>
                        <li>
                            <a href="<?php echo e(asset('/medicine/view')); ?>">View Medicine</a>
                        </li>
                    </ul>
                </li>
             <?php endif; ?>

             <?php if(Auth::user()->role==1): ?>
                <li class="has_sub">
                    <a href="#" class="waves-effect">
                        <i class="md md-redeem"></i>
                        <span>
                            Employee
                        </span>
                        <span class="pull-right">
                            <i class="md md-add"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled">
                        <li>
                            <a href="<?php echo e(route('register')); ?>">Create Employee</a>
                        </li>

                        <li>
                            <a href="<?php echo e(asset('/employee/view')); ?>">View Employee</a>
                        </li>
                    </ul>
                </li>
             <?php endif; ?>


            <?php if(Auth::user()->role==1): ?>
                <li class="has_sub">
                    <a href="#" class="waves-effect">
                        <i class="fa fa-sellsy"></i>
                        <span>
                            Customer
                        </span>
                        <span class="pull-right">
                            <i class="md md-add"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled">
                        <li>
                            <a href="<?php echo e(route('add')); ?>">Add Customer</a>
                        </li>
                        <li>
                            <a href="<?php echo e(asset('/customar/view')); ?>">View Customer</a>
                        </li>
                    </ul>
                </li>
            <?php elseif(Auth::user()->role==2): ?>
                <li>
                    <a href="<?php echo e(route('add')); ?>" class="waves-effect">
                        <i class="fa fa-sellsy"></i>
                        <span>
                            Add New Customer
                        </span>
                    </a>
                </li>
            <?php endif; ?>


            <?php if(Auth::user()->role==1): ?>
                <li class="has_sub">
                    <a href="#" class="waves-effect">
                        <i class="md md-invert-colors-on"></i>
                        <span>
                            Category
                        </span>
                        <span class="pull-right">
                            <i class="md md-add"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled">
                        
                        <li>
                            <a href="<?php echo e(asset('/add/category')); ?>">Add Category</a>
                        </li>
                        <li>
                            <a href="<?php echo e(asset('/category')); ?>">View Category</a>
                        </li>
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="#" class="waves-effect">
                        <i class="md md-invert-colors-on"></i>
                        <span>
                            Manufacturer
                        </span>
                        <span class="pull-right">
                            <i class="md md-add"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled">
                        
                        <li>
                            <a href="<?php echo e(asset('/manufacturer')); ?> ">Manufacturer
                            </a>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
            </ul>
            <div class="mx-auto text-center">
                <img  src="<?php echo e(asset('frontend/images/Global_Pharma.gif')); ?>" alt="Pharmacy Photo" height="auto" width="85%" >
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<script>
    $(function() {
        $('nav a[href^="/' + location.pathname.split("/")[1] + '"]').addClass('current');
    });
</script>
<?php /**PATH C:\xampp\htdocs\Pharmecy-Managment\resources\views/frontend/dashboard/partials/sidebar.blade.php ENDPATH**/ ?>