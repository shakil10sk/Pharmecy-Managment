<?php

namespace App\POS;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
}
