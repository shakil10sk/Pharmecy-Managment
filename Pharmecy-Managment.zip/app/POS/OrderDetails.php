<?php

namespace App\POS;

use Illuminate\Database\Eloquent\Model;

class OrderDetails extends Model
{
    //
}
